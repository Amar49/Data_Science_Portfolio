import pandas as pd
class Pandas_Test:
	def __init__(self,file):
		self.df = pd.read_csv(file)
		print(self.df.iloc[0:5])

#1.      List all the products

	def prods(self):
		
		g = self.df.groupby('Product')
		for prod,prod_df in g:
			print([prod,len(prod_df)])

#2.      List all country names

	def country(self):

		g = self.df.groupby('Retailer country')
		for coun,coun_df in g:
			print([coun,len(coun_df)])

#4.      List the product which is able to sell maximum numbers in United States

	def maxUS(self):
		
		l = self.df[(self.df['Retailer country'] == 'United States')]
		g = l.groupby('Product')['Quantity'].sum().max()
		print(g)
		
		'''for prod,prod_df in g:
			maxi = 0		
			print([prod,len(prod_df)])

			if len(prod_df)>maxi:
				maxi = len(prod_df)
				name = prod
		'''
		#print "Maximum selling prod in US is {0} with {1} sold ".format(name,maxi)



#5.      Find the order method type which is able to sell more number of products in Germany

	def Order(self):

		l = self.df[(self.df['Retailer country']=='Germany')]
		g = l.groupby('Order method type')
		
		for prod,prod_df in g:
			maxi = 0		
			print([prod,len(prod_df)])

			if len(prod_df)>maxi:
				maxi = len(prod_df)
				name = prod
		
		print "Maximum Order Type in UGermany is {0} with {1} products sold ".format(name,maxi)

#6.		List the top 5 products which has more gross profit in Australia
	def top5(self):
		
		self.df['Gross profit'].fillna(0) 

		l = self.df[(self.df['Retailer country']=='Australia')]
		g = l.groupby('Product')
		total_Profit = g['Gross profit'].sum()
		descend_sorted = total_Profit.sort_values(ascending=False)
		print(descend_sorted[:5])

#7.		Which order method is more popular (based on Quantity) world wide?
	
	def popularOrder(self):
		
		self.df['Quantity'].fillna(0)

		g = self.df.groupby('Order method type')
		quant = g['Quantity'].sum()
		descend_sorted = quant.sort_values(ascending=False)
		print(descend_sorted[:5])

#8.		Show the percentage of order methods for 'Flicker Lantern' in Denmark.

	def OrderPercent(self):
		
		l = self.df.loc[(self.df['Retailer country']=='Denmark') & (self.df['Product']=='Flicker Lantern')]
		g = l.groupby('Order method type')
		
		all_order_len = len(l.iloc[0])

		for ord,ord_df in g:
			print [ord, len(ord_df)/float(all_order_len)*100]

#9.      Show the Gross Profit for 'BugShield Spray' in United States by all order methods from 2004 to 2007

	def GrossProfit(self):
	
		self.df['Gross profit'].fillna(0,inplace = True)	
		l = self.df[(self.df['Retailer country'] == 'United States') & (self.df['Product'] == 'BugShield Spray') & ((self.df['Year'] > 2003) & (self.df['Year'] < 2007))]

		g = l.groupby('Order method type')
		print(g['Gross profit'].sum())
		
#10.   List the top and bottom three products sold in Canada in year 2006

	def TopBottom3Canada2006(self):
	
		l = self.df.loc[(self.df['Year']==2006) & (self.df['Retailer country']=='Canada')]
		g = l.groupby('Product')
		#for prod,prod_df in g:
		#	print([prod,len(prod_df)])
		descend_sorted = g['Product'].count().sort_values(ascending=True)
		print("Top 3 Products in Canada  : ",descend_sorted[:3])
		print("Bottom 3 Products in Canada  : ",descend_sorted[-3:])

s1 = Pandas_Test('set 1.csv')
#s1.prods()
#s1.country()
s1.maxUS()
#s1.Order()
#s1.top5()
#s1.TopBottom3Canada2006()
#s1.popularOrder()
#s1.OrderPercent()
#s1.GrossProfit()
