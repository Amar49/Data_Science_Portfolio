from geopy.geocoders import Nominatim
import MySQLdb
import pandas as pd 

geolocator = Nominatim(timeout=None)


db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="Asupra*007$",
                     db="Road_Safety")

cursor = db.cursor()

# Execute SQL select statement
sql="SELECT `Accident_Index`,`Latitude`,`Longitude`,`Number_of_Casualties`  FROM `Accident`"
cursor.execute(sql)
rows=cursor.fetchall()

#Transforming data into DataFrames
df=pd.DataFrame([[j for j in i] for i in rows])
#print(df)

df.to_csv('hello.csv')
