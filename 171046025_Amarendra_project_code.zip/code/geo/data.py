import pandas as pd

def fill_with_zeroes(dataset):
	dataset.fillna(0)
	dataset.to_csv("Accidents_2009.csv")

df = pd.read_csv("Accidents_2009.csv")
fill_with_zeroes(df)
