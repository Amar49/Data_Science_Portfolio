import pandas as pd
import sys
from geopy.geocoders import Nominatim
import time

df = pd.read_csv("hello2.csv",names=['Accident_Index','Latitude','Longitude','Number_of_Casualties'])

geolocator = Nominatim()
'''
fields = ['Accident_Index','Latitude','Longitude','Number_of_Casualties']
df = pd.read_csv('sample.csv',usecols=fields)
'''
#step 1. select 'Accident_Index','Latitude','Longitude','Number_of_Casualties' 
#step 2. load in a df

print(df)
cities = []
for i in range(len(df['Latitude'])):
	#print(df.iloc[i]['Latitude'],df.iloc[i]['Longitude'])
	location = geolocator.reverse((df.iloc[i]['Latitude'], df.iloc[i]['Longitude']))
	#location = geolocator.reverse("51.505538000000001, -0.198465")
	city = location.address.split(',')
	print(city)
	cities.append(city)
print(cities)
df['cities'] = cities
df.to_csv("city.csv")
print(df)
