import pandas as pd

df = pd.read_csv('city.csv')
print(df['cities'])

cities = list(df['cities'])

city =[]
state = []
country =[]

for i in range(len(cities)):
	cities[i] = cities[i].split(',')
	city.append(cities[i][-5])
	state.append(cities[i][-4])
	country.append(cities[i][-3])

#print(cities)

maps = pd.DataFrame({'city' : city, 'state' : state, 'country' : country, 'Casualities' : df['Number_of_Casualties']})
'''print(maps['city'].unique())
print(len(maps['city'].unique()))

l = maps.groupby(maps['city'])
Casual_per_city = l['Casualities'].sum()

print(Casual_per_city)

maps = pd.DataFrame({'city' : Casual_per_city.index,'Casualities' :Casual_per_city.values})
print(maps)

maps.to_csv("asha.csv")'''

print(maps['country'].unique())
print(len(maps['country'].unique()))

l = maps.groupby(maps['country'])
Casual_per_city = l['Casualities'].sum()

print(Casual_per_city)

maps = pd.DataFrame({'country' : Casual_per_city.index,'Casualities' :Casual_per_city.values})
print(maps)

maps.to_csv("asha_country.csv")
