import pandas as pd
import random

# The data to load
f = "hello.csv"

# Count the lines
#num_lines = sum(1 for l in open(f))
num_lines =321486
# Sample size - in this case ~10%
#size = int(num_lines / 10)
size = 1000
# The row indices to skip - make sure 0 is not included to keep the header!
skip_idx = random.sample(range(1, num_lines), num_lines - size)

# Read the data
data = pd.read_csv(f, skiprows=skip_idx)
print(data)

data.to_csv("hello2.csv")

'''import pandas
import random

n = 321486 #number of records in file
s = 1000 #desired sample size
filename = "hello.csv"
skip = sorted(random.sample(xrange(n),n-s))
df = pandas.read_csv(filename, skiprows=skip)
df.to_csv("hello2.csv")'''
