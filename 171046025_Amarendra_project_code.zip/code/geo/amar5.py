import MySQLdb
import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt

def boxplt():
	# Connect
	db = MySQLdb.connect(host="localhost",
                     user="root",
                     passwd="Asupra*007$",
                     db="Road_Safety")

	cursor = db.cursor()

	# Execute SQL select statement
	sql="SELECT `Accident_Index`,`Number_of_Vehicles`,`Number_of_Casualties`, `Accident_Severity`, `Urban_or_Rural_Area`,`Day_of_Week` FROM `Accident` " 
	
	cursor.execute(sql)
	rows=cursor.fetchall()

	#Transforming data into DataFrames

	df=pd.DataFrame([[j for j in i] for i in rows])
	print(df[2].head(5))
	data = df[1]
	plt.boxplot(data,0, '',0)
	plt.title("Box Plot")
	#plt.ylabel("Week")
	plt.xlabel("Number Of Vehicles involved in Accidents")
	plt.show()
	
	'''
	x = df[2]
	bins = np.linspace(0,6,6)
	plt.hist(x, bins, alpha=0.5, label='x')
	plt.show()
'''

boxplt()
	
	
	
	
'''Box
	import matplotlib.pyplot as plt
import numpy as np

data = [np.random.normal(0, std, 1000) for std in range(1, 6)]
plt.boxplot(data, notch=True, patch_artist=True)

plt.show()

hist

import random
import numpy
from matplotlib import pyplot

x = [random.gauss(3,1) for _ in range(400)]
y = [random.gauss(4,2) for _ in range(400)]

bins = numpy.linspace(-10, 10, 100)

pyplot.hist(x, bins, alpha=0.5, label='x')
pyplot.hist(y, bins, alpha=0.5, label='y')
pyplot.legend(loc='upper right')
pyplot.show() '''
