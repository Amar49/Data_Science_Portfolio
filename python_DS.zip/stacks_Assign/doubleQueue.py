'''len (), add_first(), add_last(), delete_first(), delete_last(), first() and last(). Double-ended queue should be of fixed capacity. When queue is full, inserting element from one end should cause an element to be lost from the opposite side'''
class LDoubleQueue:
	capacity = 10
	def __init__(self):
		self.size = 0
		self.front = 0
		self.rare = -1
		self.data = []
	def length(self):
		return self.size
	def isempty(self):
		return self.size == 0
	def isfull(self):
		return self.size == LDoubleQueue.capacity
	def add_first(self,key):
		if not self.isfull():	
			self.data.insert(self.front,key)
			self.rare+=1
			self.size+=1
		else:
			self.data.insert(self.front,key)
	def add_last(self,key):
			if not self.isfull():
					self.data.insert(self.rare+1,key)
					self.rare+=1
					self.size+=1
			else:
					self.data.insert(self.rare+1,key)
					self.rare+=1
					self.front+=1
	def delete_first(self):
		if not self.isempty():
			del self.data[self.front]
			self.rare-=1
			self.size-=1
	def delete_last(self):
		if not self.isempty():
			del self.data[self.rare]
			self.rare-=1
			self.size-=1
	def first(self):
		if not self.isempty():
			return self.data[self.front]
	def last(self):
		if not self.isempty():
			return self.data[self.rare]



