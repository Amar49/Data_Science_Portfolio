import doubleQueue
q1 = doubleQueue.LDoubleQueue()

def print_Q(fir,las):
		l=[q1.data[i] for i in range(fir,las+1)]
		print(l)

q1.add_first(30)
q1.add_first(20)
q1.add_first(10)
q1.add_last(40)
q1.add_last(50)
print_Q(q1.front,q1.rare)
print(q1.rare)
print(q1.first())

'''q1.delete_first()
q1.delete_first()
q1.delete_last()'''
q1.add_last(60)
q1.add_last(70)
q1.add_last(80)
q1.add_last(90)
q1.add_last(100)
q1.add_last(110)
q1.add_first(8)
q1.add_first(6)
q1.add_first(4)

print_Q(q1.front,q1.size)
print(q1.rare)

q1.add_first(2)
q1.add_last(120)
q1.add_last(130)
print_Q(q1.front,q1.rare)

print(q1.length())
print(q1.first())
print(q1.last())
print(q1.isempty())
print(q1.isfull())