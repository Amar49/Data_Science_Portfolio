class MaxHeap:
	def __init__(self,lst=[]):
		self.data = lst
		
	def parent(self,i):
		return ((i-1)//2)
	
	def left(self,i):
		return ((2*i)+1)
	
	def right(self,i):
		return ((2*i)+2)
	
	def length(self):
		return len(self.data)

	def is_empty(self):
		return len(self.data) == 0

	def swap(self,i,j):
		self.data[i],self.data[j] = self.data[j],self.data[i]

	def upheap(self,j):
		parent = self.parent(j)
		if j>0 and self.data[j]<self.data[parent]:
			self.swap(j,parent)
			self.upheap(parent)

	def downheap(self,j,size):
		if self.left(j) < size:
			left = self.left(j)
			bigchild = left
			if self.right(j) < size:
				right = self.right(j)
				if self.data[right]>self.data[left]:
					bigchild = right
			if self.data[bigchild] > self.data[j]:
				self.swap(bigchild,j)
				self.downheap(bigchild,size)

	def build_heap(self):
		length = self.length()
		if length>1:
			start = (length-2)//2
			for i in range(start,-1,-1):
				self.downheap(i,length)
			print(self.data)

	def getMin(self):
		return self.data[0]

	def delete_Min(self):
		if not self.is_empty():
			self.swap(0,self.length()-1)
			data = self.data.pop()
			self.downheap(0,self.length()-1)
			print(self.data)

 	def delete_J(self,j):
		if not self.is_empty() and j < self.length():
			self.swap(j,self.length()-1)
			data = self.data.pop()
			self.downheap(j,self.length()-1)
			print(self.data)

	def heap_Sort(self):
		if not self.is_empty():
			for i in range(self.length()-1,0,-1):
				self.swap(0,i)
				self.downheap(0,i)
		print(self.data)

obj = MaxHeap([1,6,7,8,0,2,4,5])
obj.build_heap()
obj.delete_Min()
#obj.delete_J(2)
obj.heap_Sort()
