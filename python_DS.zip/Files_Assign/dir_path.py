import os,time
import sys

path_dir = os.path.dirname('/home/sois/Arduino/libraries')
print(path_dir)

