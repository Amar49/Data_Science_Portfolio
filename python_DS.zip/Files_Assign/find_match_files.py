import os,fnmatch,sys
files=fnmatch.filter(os.listdir(sys.argv[1]), sys.argv[2])
print(files)