import os, time
import datetime

changed = os.path.getmtime("/home/sois/Amar/ls.py")
modified = time.ctime(changed)
now=datetime.datetime.now()

if now > datetime.datetime(int(modified)):
	print 'true'
else:
	print 'false'