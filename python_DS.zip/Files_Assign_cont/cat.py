import sys
print(open(sys.argv[1]).read())