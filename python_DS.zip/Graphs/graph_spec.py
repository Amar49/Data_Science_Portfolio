import graphs

obj = graphs.Graph()
obj.add_vertex('A')
obj.add_vertex('B')
obj.add_vertex('C')
obj.add_vertex('D')
obj.add_vertex('E')
obj.add_vertex('F')
obj.add_vertex('G')
obj.add_vertex('H')

print(obj.get_vertices())
obj.add_edge('A','B',10)
obj.add_edge('A','G',15)
obj.add_edge('A','D',18)
obj.add_edge('F','B',10)
obj.add_edge('G','E',15)
obj.add_edge('B','E',18)
obj.add_edge('F','D',10)
obj.add_edge('F','C',15)
obj.add_edge('H','C',18)

print(obj.get_adjacent('A'))

obj.dfs_Traverse('A')
obj.bfs_Traverse('A')

print(obj.dijk(''))
