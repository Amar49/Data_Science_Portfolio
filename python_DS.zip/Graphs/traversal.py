import graphs

def dfs_Traverse(self,start):

	visited = {}
	self.__makeNull()
	self.__dfs_Traverse(start,visited)

def __makeNull(self):

	neighbours = self.get_vertices()
	for node in neighbours:
		visited[node] = False

def __dfs_Traverse(start,visited):

	visited[start] = True
	print(start)
	neighbours = self.get_vertices()
	for node in neighbours:
		if not visited[node]:
			self.__dfs_Traverse(start)

def __bfs_Traverse(start):
	visited = {}
	self.__makeNull(visited)
	visited[start] = True
	print("BFS is Satrted",start)
	q = queues.FlexiQueue()
	q.enque(start)
	while not q.is_empty():
		neighbours = self.adjacent_list[start].get_neighbours()
		q.deque()
		for node in neighbours:
			if not visited[node]:
				visited[node] = False
				print(node)
				q.deque()



