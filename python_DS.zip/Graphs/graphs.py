import sys
import queues

class Graph:
	class Vertex:
		def __init__(self,node):
			self.node_id = node
			self.adjacent = {}
		def is_neighbour(self,node):
			return node in self.adjacent
		def get_neighbours(self):
			return self.adjacent
		def get_node_id(self):
			return self.node_id
		def add_neighbour(self,node,weight=0):
			if not self.is_neighbour(node):
				self.adjacent[node] = weight
		def get_cost(self,node):
			if is_neighbour(node):
				return adjacent[node]
			else:
				return sys.maxsize
	def __init__(self):
		self.adjacent_list = {}
		self.graph_size = 0
	def is_vertex(self,node):
		return node in self.adjacent_list
	def is_empty(self):
		return self.graph_size == 0
	def get_count(self):
		return self.graph_size
	def add_vertex(self,node):
		if node not in self.adjacent_list:
			self.graph_size += 1
			new_node = self.Vertex(node)
			self.adjacent_list[node] = new_node
	def add_edge(self,frm,to,weight=0):
		if not frm in self.adjacent_list:
			self.add_vertex(frm)
		if not to in self.adjacent_list:
			self.add_vertex(to)
		self.adjacent_list[frm].add_neighbour(to,weight)
		self.adjacent_list[to].add_neighbour(frm,weight)
	def get_vertices(self):
		return self.adjacent_list.keys()
	def get_adjacent(self,node):
		if node in self.adjacent_list:
			neighbours = self.adjacent_list[node].get_neighbours()
			neighbour_list = []
			for v in neighbours:
				neighbour_list = neighbour_list + [v]
			return neighbour_list
			#return neighbours.keys()
	def get_edge_cost(self,frm,to):
		if frm in self.adjacent_list and to in self.adjacent_list:
			return self.adjacent_list[frm].get_cost(to)
	'''def find_path(self,start,end,path = []):
		if start in self.adjacent_list:
			path = path +[start]
			if start == end:
				return path
			else:
				for i in neighbours:
					if i not in path
						neighbours = self.get_adjacent(start)
		'''
					
	def dfs_Traverse(self,start):

		visited = {}
		visited = self.__makeNull(visited)
		self.__dfs_Traverse(start,visited)

	def __makeNull(self,visited):

		neighbours = self.get_vertices()
		for node in neighbours:
			visited[node] = False
		return visited

	def __dfs_Traverse(self,start,visited):

		visited[start] = True
		print(start)
		neighbours = self.adjacent_list[start].get_neighbours()
		for node in neighbours:
			if not visited[node]:
				self.__dfs_Traverse(node,visited)
	def bfs_Traverse(self,start):
		visited = {}
		self.__makeNull(visited)
		visited[start] = True
		print("BFS is Satrted",start)
		q = queues.FlexiQueue()
		q.enque(start)
		while not q.isempty():
			node = q.deque()
			neighbours = self.adjacent_list[node].get_neighbours()
			for node in neighbours:
				if not visited[node]:
					visited[node] = True
					print(node)
					q.enque(node)

	def dijk(self,src):
		dist = []
		visit = []
		vertex_list = self.get_vertices()
		for node in vertex_list:
			visit[node] = False
			dist[node] = self.get_cost(src,node)
		visit[src] = True
		dist[src] = 0

		for node in vertex_list:
			vertex = self.choose_min(visit,dist)
			visit[vertex] = True
			for node1 in vertex_list:
				if not visit[node1]:
					new_cost = dist[vertex]+self.adjacent_list[vertex].get_cost(node1)
					if new_cost < dist[node1]:
						dist[node1] = new_cost
		return dist

	def choose_min(visit,dist):
		vertex_list = self.get_vertices()
		min = sys.maxsize
		nearest = None
		for node in vertex_list:
			if not visit[node] and dist[node]<min:
				min = dist[node]
				nearest = node
		return nearest


