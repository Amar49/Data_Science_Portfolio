import SLL
s1 = SLL.SLL()
s1.add_first(40)
s1.add_first(30)
s1.add_first(20)
s1.add_first(10)
s1.add_last(50)
s1.add_last(60)
s1.add_last(70)
s1.add_last(80)
def print_list(head):
	cur = head
	while cur != None:
		print cur.data
		cur = cur.next
print_list(s1.head)
print(s1.length())
s1.add_at_mid(10,1)
s1.add_at_mid(12,0)
s1.add_at_mid(14,10)
print(s1.length())