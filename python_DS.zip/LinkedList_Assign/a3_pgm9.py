import SLL
s1 = SLL.SLL()

def unique(ele):
	if not s1.is_member(ele):
		s1.add_last(ele)

unique(10)
unique(10)
unique(20)
unique(20)
unique(30)
unique(30)
unique(40)

def print_list(head):
	cur = head
	while cur != None:
		print cur.data
		cur = cur.next

print_list(s1.head)