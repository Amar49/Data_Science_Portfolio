class SLL:
	class _Node:
		def __init__(self,ele):
			self.data = ele
			self.next = None
	def __init__(self):
		self.head = None
		self.tail = None
		self.count = 0
	def isempty(self):
		return self.count == 0
	def length(self):
		return self.count
	def first(self):
		if not self.isempty():
			return self.head.data
	def last(self):
		if not self.isempty():
			return self.tail.data
	def add_first(self,val):
		new_node = self._Node(val)
		if not self.isempty():
			new_node.next=self.head
			self.head = new_node
		else:
			self.head = self.tail = new_node
		self.count+=1

	def add_last(self,val):
		new_node = self._Node(val)
		if not self.isempty():
			self.tail.next = new_node
			self.tail = new_node
		else:
			self.head = self.tail = new_node
		self.count+=1
	def del_first(self):
		if not self.isempty():
			data = self.head.data
			self.head = self.head.next
			if self.head.next == None:
				self.tail=self.head
		self.count-=1
		return data
	def del_last(self):
		if not self.isempty():
			data = self.tail.data
			if self.count == 1:
				self.head=self.tail=None
			else:
				cur = self.head
				last = self.tail
				while cur.next is not last:
					cur = cur.next
				self.tail=cur
				self.tail.next = None 
		self.count-=1
		return data
	def is_member(self,key):
		if not self.isempty():
			cur = self.head
			while cur is not None:
				if cur.data == key:
					break
				else:
					cur = cur.next
			return cur != None
	def min_max(self,head):
		if not self.isempty():
			cur = head
			max = head.data
			min = head.data
			while cur != None:
				if cur.data > max:
					max = cur.data
				if cur.data < min:
					min = cur.data
				cur = cur.next
			mm = [max,min]
			return mm
	def add_at_mid(self,val,after):
		if 0 < after < self.count:
			new_node = self._Node(val)
			cur = self.head
			counter = 1
			while counter != after:
				cur = cur.next
				counter += 1
			new_node.next = cur.next
			cur.next = new_node
			self.count+=1
	def del_at_mid(self,after):
		if 0 < after < self.count:
			cur = self.head
			counter = 1
			while counter != after:
				cur = cur.next
				counter += 1
			delete = cur.next
			cur.next = delete.next
			delete.next = None
			self.count-=1
