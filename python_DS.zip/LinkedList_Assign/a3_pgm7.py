import SLL
s1 = SLL.SLL()
s2 = SLL.SLL()
s3 = SLL.SLL()

s1.add_first(40)
s1.add_first(30)
s1.add_first(40)
s1.add_first(20)
s1.add_first(0)
s1.add_first(10)

s2.add_last(10)
s2.add_last(20)
s2.add_first(40)
s2.add_last(30)
s2.add_last(40)

def union(head1,head2):
  if head1!= None and head2 != None:	
	cur1,cur2=head1,head2
	while(cur1 != None and cur2 != None):
		if (cur1.data == cur2.data):
			if not s3.is_member(cur1.data):	
				s3.add_last(cur1.data)
		else:
			if not s3.is_member(cur1.data):
			  s3.add_last(cur1.data)
			if not s3.is_member(cur2.data):  
			  s3.add_last(cur2.data)
		cur1 = cur1.next
		cur2 = cur2.next
	if cur1 != None:
		if not s3.is_member(cur1.data):
		 s3.add_last(cur1.data)
		cur1 = cur1.next
	if cur2 != None:
		if not s3.is_member(cur2.data):
		 s3.add_last(cur2.data)
		cur2 = cur2.next

union(s1.head,s2.head)

def print_list(head):
	cur = head
	while cur != None:
		print cur.data
		cur = cur.next

print_list(s3.head)