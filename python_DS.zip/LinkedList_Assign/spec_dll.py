import DLL
s1 = DLL.DLL()

s1.add_first(40)
s1.add_first(30)
s1.add_first(20)
s1.add_first(10)

s1.add_last(50)
s1.add_last(60)
s1.add_first(0)
s1.add_last(70)
s1.add_last(80)

def print_list(head):
	cur = head
	while cur != None:
		print(cur.data)
		cur = cur.prev

print(s1.isempty())
print(s1.is_member(20))

'''s1.del_last()
s1.del_first()
s1.del_at_mid(3)'''
s1.add_at_mid(35,1)

print(s1.length())

print_list(s1.tail)