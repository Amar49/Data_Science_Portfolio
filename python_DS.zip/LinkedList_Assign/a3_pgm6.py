mport SLL
s1 = SLL.SLL()
s2 = SLL.SLL()
s1.add_first(40)
s1.add_first(40)
s1.add_first(30)
s1.add_first(20)
s1.add_first(10)
s2.add_last(10)
s2.add_last(20)
s2.add_last(30)
s2.add_last(40)
s2.add_last(40)
'''def print_list(head):
	cur = head
	while cur != None:
		print cur.data
		cur = cur.next
print_list(s1.head)'''


'''Create two separate single lists. Check two list are same. If the two lists have the same number of elements in the same order, then they are treated as same.'''
def cmp(head1,head2):
	cur1,cur2=head1,head2
	while(cur1 != None and cur2 != None):
		if cur1.data == cur2.data:
			cur1 = cur1.next
			cur2 = cur2.next
		else:
			return 0
	if((cur1 != None and cur2 == None)or(cur1 == None and cur2 != None)):
		return 0
	else:
		return 1
same = cmp(s1.head,s2.head)
print("Same = ",same)